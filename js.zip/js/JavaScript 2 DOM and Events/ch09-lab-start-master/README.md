# Fundamentals of Web Development, 2nd Edition
### Chapter 9 [JavaScript 2: DOM and Events], Lab

What You Will Learn
* Accessing and modifying DOM HTML elements using JavaScript
* Creating event listeners to react to events
* Tools and tricks to help you develop JavaScript